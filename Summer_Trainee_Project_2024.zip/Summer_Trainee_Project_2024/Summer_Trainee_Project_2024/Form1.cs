﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using ZedGraph;
using System.IO;


namespace Summer_Trainee_Project_2024
{
    public partial class Form1 : Form
    {
        byte[] data = new byte[1024];
        int size = 1024;
        Socket _serverSocket;
        Socket _clientSocket;
        NetworkStream ns;

        // //static int vechile_counter = 0;
        //// private Socket server;
        private byte[] data1 = new byte[1024];
        public Form1()
        {
            InitializeComponent();
            //StartServer();
        }
        Thread _nsThread;
        private void StartServer()
        {
            try
            {

                _serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPEndPoint iep = new IPEndPoint(IPAddress.Any, 2718);
                _serverSocket.Bind(iep);
                _serverSocket.Listen(0);
                _clientSocket = _serverSocket.Accept();
                byte[] data = Encoding.ASCII.GetBytes("CONNECTION");
                byte[] rec = new byte[7];
                _clientSocket.SendTo(data, _clientSocket.RemoteEndPoint);
                _clientSocket.Receive(rec);

                if (Encoding.ASCII.GetString(rec) == "SUCCESS")
                {
                    displaytext("Connected to: " + _clientSocket.RemoteEndPoint.ToString());
                    ns = new NetworkStream(_clientSocket);

                    _nsThread = new Thread(new ThreadStart(_readData));
                    _nsThread.Start();
                    _isThreadCreated = true;
                    btn_start.Enabled = true;
                }
                else
                {
                    displaytext("Connected failed... Please check connection");
                    btn_establishment_connection.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                //  result_listBox.Items.Add(ex.Message);
                // txt_activity.Items.Add(ex.Message);
                displaytext(ex.Message + "\n");
                btn_establishment_connection.Enabled = false;
            }
        }
        bool _stopAck = false;
        List<string> _indata = new List<string>();
        int _startPoint = 0;
        byte[] rec = new byte[4];
        void _readData()
        {

            while (true)
            {

                if (ns.DataAvailable)
                    _clientSocket.Receive(rec);
                if (_stopAck)
                {
                    _indata.Insert(_startPoint, Encoding.ASCII.GetString(rec).Replace("\0", string.Empty).Replace(",", string.Empty));
                    _startPoint++;
                }
            }
        }

        void AcceptConn(IAsyncResult iar)
        {


            try
            {
                Socket oldserver = (Socket)iar.AsyncState;
                Socket client = oldserver.EndAccept(iar);
                string stringData = "C";
                byte[] message1 = Encoding.ASCII.GetBytes(stringData);
                client.BeginSend(message1, 0, message1.Length, SocketFlags.None,
                    new AsyncCallback(SendData), client);
            }
            catch (Exception ex)
            {
                richTextBox1_log.Text = (ex.Message + "\n");

            }

        }
        void SendData(IAsyncResult iar)
        {
            Socket client = (Socket)iar.AsyncState;
            int sent = client.EndSend(iar);
            byte[] message1 = Encoding.ASCII.GetBytes("STOPP".Trim());
            client.BeginSend(message1, 0, message1.Length, SocketFlags.None,
                new AsyncCallback(ReceiveData), client);

        }
        string receivedData = null;
        bool stopListining = true;
        bool _isThreadCreated = false;
        void ReceiveData(IAsyncResult iar)
        {
            string REC_DATA = null;
            try
            {
                Socket client = (Socket)iar.AsyncState;
                int recv = client.EndSend(iar);
                if (recv == 0)
                {
                    client.Close();
                    richTextBox1_log.Text = ("Waiting for Arduino client..." + "\n");
                    _serverSocket.BeginAccept(new AsyncCallback(AcceptConn), _serverSocket);
                    return;
                }
                receivedData += Encoding.ASCII.GetString(data, 0, recv);
                receivedData += ",";
                if (!stopListining)
                    client.BeginReceive(data, 0, size, SocketFlags.None,
                  new AsyncCallback(ReceiveData), client);
            }
            catch (Exception ex)
            {
                richTextBox1_log.Text = (ex.Message + "\n");
                // StartServer();
            }

        }
       /* private void cmb_serial_port_DropDown(object sender, EventArgs e)
        {
           string[] ports = SerialPort.GetPortNames();
            cmb_serial_port.Items.Clear();
            foreach (string comport in ports)
            {
               cmb_serial_port.Items.Add(comport);
            }
        }

        private void btn_scan_Click(object sender, EventArgs e)
        {
            try
           {
                if (!serialPort1.IsOpen)
                {
                    serialPort1.PortName = cmb_serial_port.Text;
                    serialPort1.BaudRate = Convert.ToInt32(txt_baudRate.Text);
                    serialPort1.Open();
                    richTextBox1_log.Text += "Selected COM Port: " + cmb_serial_port.Text + "\n";
                    richTextBox1_log.Text += "Selected Baud Rate: " + txt_baudRate.Text + "\n";
                    richTextBox1_log.Text += "Successfully connected to Arduino" + "\n";

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }*/

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {

            string rfid = null;
            rfid = serialPort1.ReadLine();
            displaytext(rfid);
        }

        private void displaytext(string data)
        {
            this.Invoke(new Action(() =>
            {
                richTextBox1_log.Text += data + " ,";
                //richTextBox1_log.Text +=;
            }));

        }
        private void OnReceive(IAsyncResult ar)
        {
            try
            {
                UdpClient u = (UdpClient)((UdpState)(ar.AsyncState)).u;
                IPEndPoint e = (IPEndPoint)((UdpState)(ar.AsyncState)).e;
                UdpState s = new UdpState();
                s.e = e;
                s.u = u;
                Byte[] receiveBytes = u.EndReceive(ar, ref e);
                string receiveString = Encoding.ASCII.GetString(receiveBytes);
                s.e = e;
                //  listBox1.Items.Add("Received:" + receiveString + e.Address.ToString());
                u.BeginReceive(new AsyncCallback(OnReceive), s);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        string _acqStartTime, _acqStopTime;
        private void btn_start_Click(object sender, EventArgs eA)
        {
            btn_start.Enabled = false;
            _startPoint = 0;
            byte[] data = Encoding.ASCII.GetBytes("START");
            _clientSocket.SendTo(data, _clientSocket.RemoteEndPoint);
            progressBar1.Value = 2;
            _stopAck = true;
            displaytext("\nAcquisition Started..");
            btn_stop.Enabled = true;
            _acqStartTime = System.DateTime.Now.ToLongTimeString();

        }
        public class UdpState
        {
            public IPEndPoint e;
            public UdpClient u;

        }
        private void btn_stop_Click(object sender, EventArgs e)
        {
            _acqStopTime = System.DateTime.Now.ToLongTimeString();
            btn_start.Enabled = true;
            byte[] data = Encoding.ASCII.GetBytes("STOPP");
            _clientSocket.SendTo(data, _clientSocket.RemoteEndPoint);
            _stopAck = false;
            progressBar1.Value = 15;
            _plotData();
            btn_stop.Enabled = false;
            displaytext("\nAcquisition Sopped");
            displaytext("\nTotal Sample: " + _indata.Count.ToString());
            string status = _binaryWriter();
            if (status == "success")
                displaytext("\nData File stored successfully");
            else
                displaytext("\nData File stored failed..\n" + status);
            progressBar1.Value = 0;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            _graphInitialize();
            btn_start.Enabled = false;
            btn_stop.Enabled = false;

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_isThreadCreated)
                _nsThread.Abort();
        }

        private void btn_establishment_connection_Click(object sender, EventArgs e)
        {
            StartServer();
        }
        private void _plotData()
        {
            GraphPane myPane = zedGraphControl1.GraphPane;
            myPane.CurveList.Clear();
            try
            {
            double x = 0, y = 0;
            PointPairList list1 = new PointPairList();
              string fileName = Path.Combine(txt_file_path.Text, txt_file_name.Text + ".dat");

              //using (BinaryWriter binWriter = new BinaryWriter(File.Open(fileName, FileMode.Create)))
              //{
              //    binWriter.Write(_acqStartTime);
              //    binWriter.Write(_acqStopTime);
              //    binWriter.Write(_indata.Count);

              progressBar1.Value = 20;
                  for (int i = 0; i < _indata.Count; i++)
                  {
                      string data = null;

                      data = _indata[i].Replace("\0", string.Empty).Replace(",", string.Empty);
                      //  displaytext(data + "\n");
                      if (data != "," && data != "")
                      {
                          //binWriter.Write(data);
                          y = Convert.ToDouble(data) * 5 / 1023;
                          x = (double)i / 1000000;
                          list1.Add(x, y);
                          x++;
                      }
                      // i++;
                  }
                  progressBar1.Value = 60;

              //}

            myPane.Title.Text = "Acoustic Signature)";
            myPane.XAxis.Title.Text = "Time[Sec]";
            myPane.YAxis.Title.Text = "Volts";

            LineItem myCurve = myPane.AddCurve("Sound Pressure",
                  list1, Color.Blue, SymbolType.None);
            zedGraphControl1.AxisChange();
            zedGraphControl1.Refresh();
            progressBar1.Value = 75;
             }
            catch (Exception ex)
            {
                displaytext("\n Plotting Error..\n"+ex.Message);
            }

        }
        private void _offlinePlot()
        {
             try
             {
            double x = 0, y = 0;
            PointPairList list1 = new PointPairList();
             string data = null;
             for (int i = 0; i < _indata.Count; i++)
             {
                data = _indata[i];
                  displaytext(data + "\n");
                if (data != "," && data != "")
                {
                    y = Convert.ToDouble(data) * 5 / 1023;
                    list1.Add(x, y);
                    x++;
                }
               
            }
            GraphPane myPane = zedGraphControl1.GraphPane;

            myPane.Title.Text = "My Test Graph\n(For CodeProject Sample)";
            myPane.XAxis.Title.Text = "My X Axis";
            myPane.YAxis.Title.Text = "My Y Axis";

            LineItem myCurve = myPane.AddCurve("Sound Pressure",
                  list1, Color.Red, SymbolType.None);
            zedGraphControl1.AxisChange();
            zedGraphControl1.Refresh();
             }
             catch (Exception ex)
             {
                 displaytext("\n Plotting Error..\n" + ex.Message);
             }

        }
        private void btn_file_path_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            folderDlg.ShowNewFolderButton = true;

            DialogResult result = folderDlg.ShowDialog();
            if (result == DialogResult.OK)
            {
                txt_file_path.Text = folderDlg.SelectedPath;
                Environment.SpecialFolder root = folderDlg.RootFolder;
            }
        }
        private string _binaryWriter()
        {
            try
            {
               
                string fileName = Path.Combine(txt_file_path.Text, txt_file_name.Text + ".dat");
                progressBar1.Value = 85;
                using (BinaryWriter binWriter = new BinaryWriter(File.Open(fileName, FileMode.Create)))
                {
                    binWriter.Write(_acqStartTime);
                    binWriter.Write(_acqStopTime);
                    binWriter.Write(_indata.Count);

                    for (int i = 0; i < _indata.Count; i++)
                    {
                        binWriter.Write(_indata[i]);//.Replace("\0", string.Empty).Replace(",", string.Empty));
                    }
                }
                progressBar1.Value = 100;
                _indata.Clear();
                return ("success");
            }
            catch (Exception ioexp)
            {
                return (ioexp.Message);
            }
        }
        private string ReadBinaryFile(string fileName)
        {
           // _indata.Clear();
            string status=null;
            Int32 _numSample;
            double x = 0, y = 0;
           // int p = 0;
            string data = null;
            PointPairList list1 = new PointPairList();
            progressBar1.Value = 50;
            using (BinaryReader reader = new BinaryReader(File.Open(fileName, FileMode.Open)))
            {
                displaytext("\nAcquisition Started at: " + reader.ReadString());
                displaytext("\nAcquisition Stopped at : " + reader.ReadString());
                _numSample = reader.ReadInt32();
                displaytext("\nTotal Number of Samples : " + _numSample);
                for (int i = 0; i < _numSample; i++)
                {
                   // _indata.Insert(i, reader.ReadString());
                    data=reader.ReadString().Replace("\0", string.Empty).Replace(",", string.Empty);
                    if (data != "," && data != "")
                    {
                        y = Convert.ToDouble(data) * 5 / 1023;
                        x = (double)i/1000000;
                        list1.Add(x, y);
                        //p++;
                    }
                }
                progressBar1.Value = 90;
               // MessageBox.Show(_indata.Count.ToString());
                //_plotData();
                GraphPane myPane = zedGraphControl1.GraphPane;

                myPane.Title.Text = "Acoustic Signature)";
                myPane.XAxis.Title.Text = "Time[Sec]";
                myPane.YAxis.Title.Text = "Volts";
                myPane.CurveList.Clear();
                LineItem myCurve = myPane.AddCurve("Sound Pressure",
                      list1, Color.Blue, SymbolType.None);
                zedGraphControl1.AxisChange();
                zedGraphControl1.Refresh();
                progressBar1.Value = 100;
            }
            return (status);
        }

        private void openDataFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string filePath = null;
            progressBar1.Value = 5;
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = @"D:\",
                Title = "Browse Text Files",

                CheckFileExists = true,
                CheckPathExists = true,

                DefaultExt = "dat",
                Filter = "dat files (*.dat)|*.dat",
                FilterIndex = 2,
                RestoreDirectory = true,

                ReadOnlyChecked = true,
                ShowReadOnly = true
            };
            progressBar1.Value = 10;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                filePath = openFileDialog1.FileName;
               // MessageBox.Show(filePath);
                ReadBinaryFile(filePath);
               // _plotData();
            }
            progressBar1.Value = 0;
        }
        private void _graphInitialize()
        {
            GraphPane myPane = zedGraphControl1.GraphPane;

            myPane.Title.Text = "(Sensor Data)";
            myPane.XAxis.Title.Text = "Time[Sec]";
            myPane.YAxis.Title.Text = "Volts";
        }

        private void zedGraphControl1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void richTextBox1_log_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }




