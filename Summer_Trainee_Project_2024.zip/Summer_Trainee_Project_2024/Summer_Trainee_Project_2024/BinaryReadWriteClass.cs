﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Summer_Trainee_Project_2024
{
    class BinaryReadWriteClass
    {
        public string WriteBinary(string _fileName, string _startdateTime, string _stopdateTime, List<string> _data)
        {
            try
            {
                string fileName = "D:\\temp\\PM.bin";
                BinaryWriter bwStream = new BinaryWriter(new FileStream(fileName, FileMode.Create));

                Encoding ascii = Encoding.ASCII;
                BinaryWriter bwEncoder = new BinaryWriter(new FileStream(fileName, FileMode.Create), ascii);

                using (BinaryWriter binWriter = new BinaryWriter(File.Open(fileName, FileMode.Create)))
                {
                    // Write string
                    binWriter.Write(_startdateTime);
                    binWriter.Write(_stopdateTime);
                    // Write string
                    // Write integer
                    binWriter.Write(_data.Count);
                    for (int i = 0; i < _data.Count; i++)
                    {
                        binWriter.Write(_data[i]);
                    }
                }
                return ("success");
            }
            catch (Exception ioexp)
            {
                return (ioexp.Message);
            }
        }
    
    }
}
